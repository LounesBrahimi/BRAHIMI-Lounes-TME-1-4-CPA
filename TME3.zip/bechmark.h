#ifndef BECHMARK_H_INCLUDED
#define BECHMARK_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void simple_bechmark(char* nom_fichier, double p, double q);

#endif // BECHMARK_H_INCLUDED
